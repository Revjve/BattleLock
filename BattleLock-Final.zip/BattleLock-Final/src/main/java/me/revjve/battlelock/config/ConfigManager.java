package me.revjve.battlelock.config;

import me.revjve.battlelock.BattleLock;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.List;

/**
 * Manages plugin configuration and per-world settings
 */
public class ConfigManager {
    
    private final BattleLock plugin;
    private FileConfiguration config;
    
    public ConfigManager(BattleLock plugin) {
        this.plugin = plugin;
        loadConfig();
    }
    
    public void loadConfig() {
        plugin.saveDefaultConfig();
        plugin.reloadConfig();
        this.config = plugin.getConfig();
    }
    
    public void reload() {
        loadConfig();
    }
    
    // General Settings
    public int getCombatDuration(World world) {
        String worldName = world.getName();
        if (config.contains("worlds.world-specific." + worldName + ".combat-duration")) {
            return config.getInt("worlds.world-specific." + worldName + ".combat-duration");
        }
        return config.getInt("combat-duration", 15);
    }
    
    public boolean isDebug() {
        return config.getBoolean("debug", false);
    }
    
    // World Settings
    public boolean isEnabledInWorld(World world) {
        boolean useBlacklist = config.getBoolean("worlds.use-blacklist", false);
        String worldName = world.getName();
        
        if (useBlacklist) {
            List<String> disabled = config.getStringList("worlds.disabled-worlds");
            return !disabled.contains(worldName);
        } else {
            List<String> enabled = config.getStringList("worlds.enabled-worlds");
            return enabled.isEmpty() || enabled.contains(worldName);
        }
    }
    
    // Restrictions
    public boolean isEnderpearLsBlocked(World world) {
        return getWorldSpecificBoolean(world, "restrictions.enderpearls", true);
    }
    
    public boolean isElytraBlocked(World world) {
        return getWorldSpecificBoolean(world, "restrictions.elytra", true);
    }
    
    public boolean isChorusFruitBlocked() {
        return config.getBoolean("restrictions.chorus-fruit", true);
    }
    
    public List<String> getBlockedItems() {
        return config.getStringList("restrictions.blocked-items");
    }
    
    public List<String> getBlockedCommands() {
        return config.getStringList("restrictions.blocked-commands");
    }
    
    public List<String> getAllowedCommands() {
        return config.getStringList("restrictions.allowed-commands");
    }
    
    public boolean isFlightDisabled() {
        return config.getBoolean("restrictions.disable-flight", true);
    }
    
    public boolean isTeleportBlocked() {
        return config.getBoolean("restrictions.block-teleport", true);
    }
    
    // Visual Effects
    public boolean isGlowingEnabled() {
        return config.getBoolean("visual-effects.glowing.enabled", true);
    }
    
    public String getGlowingColor(World world) {
        String worldName = world.getName();
        if (config.contains("worlds.world-specific." + worldName + ".visual-effects.glowing.color")) {
            return config.getString("worlds.world-specific." + worldName + ".visual-effects.glowing.color");
        }
        return config.getString("visual-effects.glowing.color", "RED");
    }
    
    public boolean isParticlesEnabled() {
        return config.getBoolean("visual-effects.particles.enabled", true);
    }
    
    public String getParticleType() {
        return config.getString("visual-effects.particles.type", "FLAME");
    }
    
    public int getParticleAmount() {
        return config.getInt("visual-effects.particles.amount", 3);
    }
    
    public int getParticleInterval() {
        return config.getInt("visual-effects.particles.interval", 20);
    }
    
    public boolean isActionBarEnabled() {
        return config.getBoolean("visual-effects.action-bar.enabled", true);
    }
    
    public String getActionBarFormat() {
        return config.getString("visual-effects.action-bar.format", "&c⚔ Combat: &e{time}s &c⚔");
    }
    
    public int getActionBarUpdateInterval() {
        return config.getInt("visual-effects.action-bar.update-interval", 10);
    }
    
    public boolean isBossBarEnabled() {
        return config.getBoolean("visual-effects.boss-bar.enabled", true);
    }
    
    public String getBossBarTitle() {
        return config.getString("visual-effects.boss-bar.title", "&c⚔ &lCOMBAT MODE &c⚔");
    }
    
    public String getBossBarColor() {
        return config.getString("visual-effects.boss-bar.color", "RED");
    }
    
    public String getBossBarStyle() {
        return config.getString("visual-effects.boss-bar.style", "SOLID");
    }
    
    public boolean showBossBarTimer() {
        return config.getBoolean("visual-effects.boss-bar.show-timer", true);
    }
    
    // Combat Logging
    public boolean isCombatLoggingEnabled() {
        return config.getBoolean("combat-logging.enabled", true);
    }
    
    public boolean shouldSpawnNPC() {
        return config.getBoolean("combat-logging.spawn-npc", true);
    }
    
    public int getNPCDuration() {
        return config.getInt("combat-logging.npc-duration", 30);
    }
    
    public boolean isNPCVulnerable() {
        return config.getBoolean("combat-logging.npc-vulnerable", true);
    }
    
    public boolean shouldKillOnLogout() {
        return config.getBoolean("combat-logging.kill-on-logout", false);
    }
    
    public boolean shouldBroadcastCombatLog() {
        return config.getBoolean("combat-logging.broadcast", true);
    }
    
    public String getCombatLogBroadcast() {
        return config.getString("combat-logging.broadcast-message", "&c{player} &7combat logged!");
    }
    
    public boolean shouldDropInventory() {
        return config.getBoolean("combat-logging.drop-inventory", true);
    }
    
    public boolean shouldDropExperience() {
        return config.getBoolean("combat-logging.drop-experience", true);
    }
    
    // Messages
    public String getPrefix() {
        return config.getString("messages.prefix", "&8[&cBattleLock&8] &7");
    }
    
    public String getCombatTaggedMessage() {
        return config.getString("messages.combat-tagged", "&cYou are now in combat!");
    }
    
    public String getCombatExpiredMessage() {
        return config.getString("messages.combat-expired", "&aYou are no longer in combat.");
    }
    
    public String getActionDeniedMessage() {
        return config.getString("messages.action-denied", "&cYou cannot do that while in combat!");
    }
    
    public String getCommandBlockedMessage() {
        return config.getString("messages.command-blocked", "&cYou cannot use that command while in combat!");
    }
    
    public String getItemBlockedMessage() {
        return config.getString("messages.item-blocked", "&cYou cannot use that item while in combat!");
    }
    
    public String getPlayerNotInCombat() {
        return config.getString("messages.player-not-in-combat", "&c{player} is not in combat.");
    }
    
    public String getPlayerInCombat() {
        return config.getString("messages.player-in-combat", "&e{player} &7is in combat.");
    }
    
    public String getCombatTagAdmin() {
        return config.getString("messages.combat-tag-admin", "&aYou tagged {player} in combat.");
    }
    
    public String getCombatUntagAdmin() {
        return config.getString("messages.combat-untag-admin", "&aYou removed {player}'s combat tag.");
    }
    
    public String getReloadSuccess() {
        return config.getString("messages.reload-success", "&aConfiguration reloaded!");
    }
    
    public String getNoPermission() {
        return config.getString("messages.no-permission", "&cYou don't have permission!");
    }
    
    // Advanced Settings
    public boolean shouldTagOnMobHit() {
        return config.getBoolean("advanced.tag-on-mob-hit", false);
    }
    
    public boolean shouldTagOnMobDamage() {
        return config.getBoolean("advanced.tag-on-mob-damage", false);
    }
    
    public boolean shouldRemoveOnDeath() {
        return config.getBoolean("advanced.remove-on-death", true);
    }
    
    public boolean shouldBlockBedSet() {
        return config.getBoolean("advanced.block-bed-set", true);
    }
    
    public boolean shouldBlockBuckets() {
        return config.getBoolean("advanced.block-buckets", true);
    }
    
    public double getMinimumDamage() {
        return config.getDouble("advanced.minimum-damage", 0.5);
    }
    
    public boolean shouldBlockItemDrop() {
        return config.getBoolean("advanced.block-item-drop", false);
    }
    
    public boolean shouldBlockItemPickup() {
        return config.getBoolean("advanced.block-item-pickup", false);
    }
    
    // Helper method for world-specific settings
    private boolean getWorldSpecificBoolean(World world, String path, boolean defaultValue) {
        String worldName = world.getName();
        String worldPath = "worlds.world-specific." + worldName + "." + path;
        
        if (config.contains(worldPath)) {
            return config.getBoolean(worldPath);
        }
        return config.getBoolean(path, defaultValue);
    }
}
