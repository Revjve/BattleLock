package me.revjve.battlelock;

import me.revjve.battlelock.commands.BattleLockCommand;
import me.revjve.battlelock.commands.CombatCommand;
import me.revjve.battlelock.config.ConfigManager;
import me.revjve.battlelock.listeners.CombatListener;
import me.revjve.battlelock.listeners.LogoutListener;
import me.revjve.battlelock.listeners.RestrictionListener;
import me.revjve.battlelock.managers.CombatManager;
import me.revjve.battlelock.managers.VisualManager;
import me.revjve.battlelock.tasks.CombatCheckTask;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * Main plugin class for BattleLock
 * Advanced combat tagging system with visual effects and configurable restrictions
 */
public class BattleLock extends JavaPlugin {
    
    private ConfigManager configManager;
    private CombatManager combatManager;
    private VisualManager visualManager;
    private CombatCheckTask combatCheckTask;
    
    @Override
    public void onEnable() {
        // ASCII art banner
        getLogger().info("  ____        _   _   _      _                _    ");
        getLogger().info(" |  _ \\      | | | | | |    | |              | |   ");
        getLogger().info(" | |_) | __ _| |_| |_| | ___| |     ___   ___| | __");
        getLogger().info(" |  _ < / _` | __| __| |/ _ \\ |    / _ \\ / __| |/ /");
        getLogger().info(" | |_) | (_| | |_| |_| |  __/ |___| (_) | (__|   < ");
        getLogger().info(" |____/ \\__,_|\\__|\\__|_|\\___|______\\___/ \\___|_|\\_\\");
        getLogger().info("");
        
        // Initialize managers
        getLogger().info("Initializing BattleLock v" + getDescription().getVersion() + "...");
        
        this.configManager = new ConfigManager(this);
        this.combatManager = new CombatManager(this);
        this.visualManager = new VisualManager(this);
        
        // Register listeners
        registerListeners();
        
        // Register commands
        registerCommands();
        
        // Start tasks
        startTasks();
        
        getLogger().info("BattleLock has been enabled successfully!");
        getLogger().info("Loaded configuration with combat duration: " + 
                configManager.getCombatDuration(Bukkit.getWorlds().get(0)) + "s");
    }
    
    @Override
    public void onDisable() {
        getLogger().info("Disabling BattleLock...");
        
        // Cancel tasks
        if (combatCheckTask != null) {
            combatCheckTask.cancel();
        }
        
        // Clean up visual effects
        if (visualManager != null) {
            visualManager.cleanup();
        }
        
        // Clear combat data
        if (combatManager != null) {
            combatManager.clearAll();
        }
        
        getLogger().info("BattleLock has been disabled successfully!");
    }
    
    /**
     * Register event listeners
     */
    private void registerListeners() {
        getServer().getPluginManager().registerEvents(new CombatListener(this), this);
        getServer().getPluginManager().registerEvents(new RestrictionListener(this), this);
        getServer().getPluginManager().registerEvents(new LogoutListener(this), this);
        
        getLogger().info("Registered event listeners");
    }
    
    /**
     * Register commands
     */
    private void registerCommands() {
        BattleLockCommand battleLockCommand = new BattleLockCommand(this);
        getCommand("battlelock").setExecutor(battleLockCommand);
        getCommand("battlelock").setTabCompleter(battleLockCommand);
        
        getCommand("combat").setExecutor(new CombatCommand(this));
        
        getLogger().info("Registered commands");
    }
    
    /**
     * Start scheduled tasks
     */
    private void startTasks() {
        this.combatCheckTask = new CombatCheckTask(this);
        this.combatCheckTask.start();
        
        getLogger().info("Started combat check task");
    }
    
    // Getters for managers
    
    public ConfigManager getConfigManager() {
        return configManager;
    }
    
    public CombatManager getCombatManager() {
        return combatManager;
    }
    
    public VisualManager getVisualManager() {
        return visualManager;
    }
}
