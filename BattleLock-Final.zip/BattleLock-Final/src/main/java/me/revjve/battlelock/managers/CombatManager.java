package me.revjve.battlelock.managers;

import me.revjve.battlelock.BattleLock;
import me.revjve.battlelock.models.CombatPlayer;
import me.revjve.battlelock.utils.MessageUtil;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Manages combat tagging for all players
 */
public class CombatManager {
    
    private final BattleLock plugin;
    private final Map<UUID, CombatPlayer> combatPlayers;
    
    public CombatManager(BattleLock plugin) {
        this.plugin = plugin;
        this.combatPlayers = new HashMap<>();
    }
    
    /**
     * Tag a player in combat
     */
    public void tagPlayer(Player player, Player attacker) {
        if (player.hasPermission("battlelock.bypass")) {
            return;
        }
        
        if (!plugin.getConfigManager().isEnabledInWorld(player.getWorld())) {
            return;
        }
        
        UUID uuid = player.getUniqueId();
        CombatPlayer combatPlayer = combatPlayers.computeIfAbsent(uuid, k -> new CombatPlayer(player));
        
        int duration = plugin.getConfigManager().getCombatDuration(player.getWorld());
        UUID attackerUuid = attacker != null ? attacker.getUniqueId() : null;
        
        boolean wasInCombat = combatPlayer.isInCombat();
        combatPlayer.tagCombat(duration, attackerUuid);
        
        // Only send message if not already in combat
        if (!wasInCombat) {
            String message = plugin.getConfigManager().getCombatTaggedMessage()
                    .replace("{time}", String.valueOf(duration));
            MessageUtil.send(player, message);
            
            // Start visual effects
            plugin.getVisualManager().startEffects(player);
        }
        
        if (plugin.getConfigManager().isDebug()) {
            plugin.getLogger().info(player.getName() + " tagged in combat for " + duration + "s");
        }
    }
    
    /**
     * Untag a player from combat
     */
    public void untagPlayer(Player player) {
        UUID uuid = player.getUniqueId();
        CombatPlayer combatPlayer = combatPlayers.get(uuid);
        
        if (combatPlayer != null && combatPlayer.isInCombat()) {
            combatPlayer.untagCombat();
            
            String message = plugin.getConfigManager().getCombatExpiredMessage();
            MessageUtil.send(player, message);
            
            // Stop visual effects
            plugin.getVisualManager().stopEffects(player);
            
            if (plugin.getConfigManager().isDebug()) {
                plugin.getLogger().info(player.getName() + " removed from combat");
            }
        }
    }
    
    /**
     * Force untag a player (admin command)
     */
    public void forceUntag(UUID uuid) {
        CombatPlayer combatPlayer = combatPlayers.get(uuid);
        if (combatPlayer != null) {
            combatPlayer.untagCombat();
        }
    }
    
    /**
     * Check if a player is in combat
     */
    public boolean isInCombat(Player player) {
        return isInCombat(player.getUniqueId());
    }
    
    public boolean isInCombat(UUID uuid) {
        CombatPlayer combatPlayer = combatPlayers.get(uuid);
        return combatPlayer != null && combatPlayer.isInCombat();
    }
    
    /**
     * Get combat player data
     */
    public CombatPlayer getCombatPlayer(UUID uuid) {
        return combatPlayers.get(uuid);
    }
    
    public CombatPlayer getCombatPlayer(Player player) {
        return combatPlayers.get(player.getUniqueId());
    }
    
    /**
     * Get remaining combat time in seconds
     */
    public long getRemainingTime(Player player) {
        CombatPlayer combatPlayer = combatPlayers.get(player.getUniqueId());
        if (combatPlayer != null) {
            return combatPlayer.getRemainingTime();
        }
        return 0;
    }
    
    /**
     * Remove player from tracking (on quit/disconnect)
     */
    public void removePlayer(UUID uuid) {
        combatPlayers.remove(uuid);
    }
    
    /**
     * Get all players currently in combat
     */
    public Map<UUID, CombatPlayer> getAllCombatPlayers() {
        return new HashMap<>(combatPlayers);
    }
    
    /**
     * Clear all combat data
     */
    public void clearAll() {
        combatPlayers.clear();
    }
}
