package me.revjve.battlelock.commands;

import me.revjve.battlelock.BattleLock;
import me.revjve.battlelock.utils.MessageUtil;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

/**
 * Command for players to check their own combat status
 */
public class CombatCommand implements CommandExecutor {
    
    private final BattleLock plugin;
    
    public CombatCommand(BattleLock plugin) {
        this.plugin = plugin;
    }
    
    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, 
                            @NotNull String label, @NotNull String[] args) {
        
        if (!(sender instanceof Player player)) {
            MessageUtil.send(sender, "&cThis command can only be used by players.");
            return true;
        }
        
        if (!plugin.getCombatManager().isInCombat(player)) {
            MessageUtil.sendWithPrefix(player,
                    plugin.getConfigManager().getPrefix(),
                    "&aYou are not in combat.");
        } else {
            long remainingTime = plugin.getCombatManager().getRemainingTime(player);
            MessageUtil.sendWithPrefix(player,
                    plugin.getConfigManager().getPrefix(),
                    "&cYou are in combat! &e" + remainingTime + "s &cremaining.");
        }
        
        return true;
    }
}
