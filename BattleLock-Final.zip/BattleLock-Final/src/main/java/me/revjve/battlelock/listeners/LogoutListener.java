package me.revjve.battlelock.listeners;

import me.revjve.battlelock.BattleLock;
import me.revjve.battlelock.utils.MessageUtil;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;

/**
 * Handles player disconnection during combat (combat logging)
 */
public class LogoutListener implements Listener {
    
    private final BattleLock plugin;
    
    public LogoutListener(BattleLock plugin) {
        this.plugin = plugin;
    }
    
    @EventHandler(priority = EventPriority.MONITOR)
    public void onPlayerQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        
        // Check if player is in combat
        if (!plugin.getCombatManager().isInCombat(player)) {
            return;
        }
        
        // Check if combat logging is enabled
        if (!plugin.getConfigManager().isCombatLoggingEnabled()) {
            plugin.getCombatManager().untagPlayer(player);
            return;
        }
        
        // Handle combat logging
        handleCombatLog(player);
        
        // Stop visual effects
        plugin.getVisualManager().stopEffects(player);
        
        // Remove from combat manager
        plugin.getCombatManager().removePlayer(player.getUniqueId());
    }
    
    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        
        // Remove any lingering combat status
        if (plugin.getCombatManager().isInCombat(player)) {
            plugin.getCombatManager().untagPlayer(player);
        }
    }
    
    /**
     * Handle combat logging penalties
     */
    private void handleCombatLog(Player player) {
        Location location = player.getLocation();
        
        // Drop inventory if configured
        if (plugin.getConfigManager().shouldDropInventory()) {
            for (ItemStack item : player.getInventory().getContents()) {
                if (item != null) {
                    location.getWorld().dropItemNaturally(location, item);
                }
            }
            player.getInventory().clear();
        }
        
        // Drop experience if configured
        if (plugin.getConfigManager().shouldDropExperience()) {
            int exp = player.getTotalExperience();
            if (exp > 0) {
                location.getWorld().spawn(location, org.bukkit.entity.ExperienceOrb.class)
                        .setExperience(exp);
            }
        }
        
        // Kill player if configured
        if (plugin.getConfigManager().shouldKillOnLogout()) {
            player.setHealth(0);
        }
        
        // Spawn NPC if configured
        if (plugin.getConfigManager().shouldSpawnNPC()) {
            spawnCombatNPC(player, location);
        }
        
        // Broadcast message
        if (plugin.getConfigManager().shouldBroadcastCombatLog()) {
            String message = plugin.getConfigManager().getCombatLogBroadcast()
                    .replace("{player}", player.getName());
            Bukkit.broadcast(MessageUtil.toComponent(
                    plugin.getConfigManager().getPrefix() + message));
            
            // Notify staff
            for (Player online : Bukkit.getOnlinePlayers()) {
                if (online.hasPermission("battlelock.notify")) {
                    MessageUtil.sendWithPrefix(online,
                            plugin.getConfigManager().getPrefix(),
                            message);
                }
            }
        }
    }
    
    /**
     * Spawn a combat NPC when player logs out
     * This is a simplified version - a full implementation would use Citizens or similar
     */
    private void spawnCombatNPC(Player player, Location location) {
        // Note: This is a placeholder for NPC spawning
        // In a production environment, you would integrate with Citizens API
        // or create a custom NPC implementation
        
        int duration = plugin.getConfigManager().getNPCDuration();
        boolean vulnerable = plugin.getConfigManager().isNPCVulnerable();
        
        if (plugin.getConfigManager().isDebug()) {
            plugin.getLogger().info("Would spawn NPC for " + player.getName() + 
                    " at " + location + " for " + duration + "s (vulnerable: " + vulnerable + ")");
        }
        
        // TODO: Implement NPC spawning with Citizens API or custom implementation
        // Example with Citizens:
        /*
        if (Bukkit.getPluginManager().isPluginEnabled("Citizens")) {
            NPCRegistry registry = CitizensAPI.getNPCRegistry();
            NPC npc = registry.createNPC(EntityType.PLAYER, player.getName());
            npc.spawn(location);
            
            // Store NPC data and handle removal after duration
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                npc.destroy();
            }, duration * 20L);
        }
        */
    }
}
