package me.revjve.battlelock.tasks;

import me.revjve.battlelock.BattleLock;
import me.revjve.battlelock.models.CombatPlayer;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.Map;
import java.util.UUID;

/**
 * Task that runs periodically to check and expire combat tags
 */
public class CombatCheckTask extends BukkitRunnable {
    
    private final BattleLock plugin;
    
    public CombatCheckTask(BattleLock plugin) {
        this.plugin = plugin;
    }
    
    @Override
    public void run() {
        Map<UUID, CombatPlayer> combatPlayers = plugin.getCombatManager().getAllCombatPlayers();
        
        for (Map.Entry<UUID, CombatPlayer> entry : combatPlayers.entrySet()) {
            UUID uuid = entry.getKey();
            CombatPlayer combatPlayer = entry.getValue();
            
            // Skip if not in combat anymore
            if (!combatPlayer.isInCombat()) {
                Player player = Bukkit.getPlayer(uuid);
                if (player != null && player.isOnline()) {
                    plugin.getCombatManager().untagPlayer(player);
                }
                continue;
            }
            
            // Check if player is still online
            Player player = Bukkit.getPlayer(uuid);
            if (player == null || !player.isOnline()) {
                continue;
            }
            
            // Check if combat has expired
            if (System.currentTimeMillis() >= combatPlayer.getCombatEndTime()) {
                plugin.getCombatManager().untagPlayer(player);
            }
        }
    }
    
    /**
     * Start the task
     */
    public void start() {
        // Run every second (20 ticks)
        this.runTaskTimer(plugin, 20L, 20L);
    }
}
