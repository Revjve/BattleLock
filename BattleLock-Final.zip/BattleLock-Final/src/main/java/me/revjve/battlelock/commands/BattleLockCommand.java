package me.revjve.battlelock.commands;

import me.revjve.battlelock.BattleLock;
import me.revjve.battlelock.models.CombatPlayer;
import me.revjve.battlelock.utils.MessageUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Main command handler for BattleLock
 */
public class BattleLockCommand implements CommandExecutor, TabCompleter {
    
    private final BattleLock plugin;
    
    public BattleLockCommand(BattleLock plugin) {
        this.plugin = plugin;
    }
    
    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, 
                            @NotNull String label, @NotNull String[] args) {
        
        // No args - show help
        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }
        
        String subCommand = args[0].toLowerCase();
        
        switch (subCommand) {
            case "reload" -> {
                return handleReload(sender);
            }
            case "status" -> {
                return handleStatus(sender, args);
            }
            case "tag" -> {
                return handleTag(sender, args);
            }
            case "untag" -> {
                return handleUntag(sender, args);
            }
            case "list" -> {
                return handleList(sender);
            }
            case "help" -> {
                sendHelp(sender);
                return true;
            }
            default -> {
                MessageUtil.sendWithPrefix(sender,
                        plugin.getConfigManager().getPrefix(),
                        "&cUnknown subcommand. Use &e/" + label + " help");
                return true;
            }
        }
    }
    
    /**
     * Reload configuration
     */
    private boolean handleReload(CommandSender sender) {
        if (!sender.hasPermission("battlelock.reload")) {
            MessageUtil.sendWithPrefix(sender,
                    plugin.getConfigManager().getPrefix(),
                    plugin.getConfigManager().getNoPermission());
            return true;
        }
        
        plugin.getConfigManager().reload();
        MessageUtil.sendWithPrefix(sender,
                plugin.getConfigManager().getPrefix(),
                plugin.getConfigManager().getReloadSuccess());
        return true;
    }
    
    /**
     * Check combat status of a player
     */
    private boolean handleStatus(CommandSender sender, String[] args) {
        if (!sender.hasPermission("battlelock.status")) {
            MessageUtil.sendWithPrefix(sender,
                    plugin.getConfigManager().getPrefix(),
                    plugin.getConfigManager().getNoPermission());
            return true;
        }
        
        Player target;
        
        if (args.length < 2) {
            if (!(sender instanceof Player)) {
                MessageUtil.sendWithPrefix(sender,
                        plugin.getConfigManager().getPrefix(),
                        "&cYou must specify a player name.");
                return true;
            }
            target = (Player) sender;
        } else {
            target = Bukkit.getPlayer(args[1]);
            if (target == null) {
                MessageUtil.sendWithPrefix(sender,
                        plugin.getConfigManager().getPrefix(),
                        "&cPlayer not found: " + args[1]);
                return true;
            }
        }
        
        if (!plugin.getCombatManager().isInCombat(target)) {
            String message = plugin.getConfigManager().getPlayerNotInCombat()
                    .replace("{player}", target.getName());
            MessageUtil.sendWithPrefix(sender,
                    plugin.getConfigManager().getPrefix(),
                    message);
        } else {
            long remainingTime = plugin.getCombatManager().getRemainingTime(target);
            String message = plugin.getConfigManager().getPlayerInCombat()
                    .replace("{player}", target.getName())
                    .replace("{time}", String.valueOf(remainingTime));
            MessageUtil.sendWithPrefix(sender,
                    plugin.getConfigManager().getPrefix(),
                    message);
        }
        
        return true;
    }
    
    /**
     * Manually tag a player in combat
     */
    private boolean handleTag(CommandSender sender, String[] args) {
        if (!sender.hasPermission("battlelock.tag")) {
            MessageUtil.sendWithPrefix(sender,
                    plugin.getConfigManager().getPrefix(),
                    plugin.getConfigManager().getNoPermission());
            return true;
        }
        
        if (args.length < 2) {
            MessageUtil.sendWithPrefix(sender,
                    plugin.getConfigManager().getPrefix(),
                    "&cUsage: /battlelock tag <player>");
            return true;
        }
        
        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) {
            MessageUtil.sendWithPrefix(sender,
                    plugin.getConfigManager().getPrefix(),
                    "&cPlayer not found: " + args[1]);
            return true;
        }
        
        plugin.getCombatManager().tagPlayer(target, null);
        
        String message = plugin.getConfigManager().getCombatTagAdmin()
                .replace("{player}", target.getName());
        MessageUtil.sendWithPrefix(sender,
                plugin.getConfigManager().getPrefix(),
                message);
        
        return true;
    }
    
    /**
     * Manually untag a player from combat
     */
    private boolean handleUntag(CommandSender sender, String[] args) {
        if (!sender.hasPermission("battlelock.untag")) {
            MessageUtil.sendWithPrefix(sender,
                    plugin.getConfigManager().getPrefix(),
                    plugin.getConfigManager().getNoPermission());
            return true;
        }
        
        if (args.length < 2) {
            MessageUtil.sendWithPrefix(sender,
                    plugin.getConfigManager().getPrefix(),
                    "&cUsage: /battlelock untag <player>");
            return true;
        }
        
        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) {
            MessageUtil.sendWithPrefix(sender,
                    plugin.getConfigManager().getPrefix(),
                    "&cPlayer not found: " + args[1]);
            return true;
        }
        
        if (!plugin.getCombatManager().isInCombat(target)) {
            String message = plugin.getConfigManager().getPlayerNotInCombat()
                    .replace("{player}", target.getName());
            MessageUtil.sendWithPrefix(sender,
                    plugin.getConfigManager().getPrefix(),
                    message);
            return true;
        }
        
        plugin.getCombatManager().untagPlayer(target);
        
        String message = plugin.getConfigManager().getCombatUntagAdmin()
                .replace("{player}", target.getName());
        MessageUtil.sendWithPrefix(sender,
                plugin.getConfigManager().getPrefix(),
                message);
        
        return true;
    }
    
    /**
     * List all players in combat
     */
    private boolean handleList(CommandSender sender) {
        if (!sender.hasPermission("battlelock.status")) {
            MessageUtil.sendWithPrefix(sender,
                    plugin.getConfigManager().getPrefix(),
                    plugin.getConfigManager().getNoPermission());
            return true;
        }
        
        List<Player> inCombat = new ArrayList<>();
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (plugin.getCombatManager().isInCombat(player)) {
                inCombat.add(player);
            }
        }
        
        if (inCombat.isEmpty()) {
            MessageUtil.sendWithPrefix(sender,
                    plugin.getConfigManager().getPrefix(),
                    "&7No players are currently in combat.");
        } else {
            MessageUtil.sendWithPrefix(sender,
                    plugin.getConfigManager().getPrefix(),
                    "&ePlayers in combat (" + inCombat.size() + "):");
            
            for (Player player : inCombat) {
                long time = plugin.getCombatManager().getRemainingTime(player);
                MessageUtil.send(sender, 
                        "&7- &e" + player.getName() + " &7(" + time + "s remaining)");
            }
        }
        
        return true;
    }
    
    /**
     * Send help message
     */
    private void sendHelp(CommandSender sender) {
        MessageUtil.send(sender, "&8&m-----------------------------");
        MessageUtil.send(sender, "&c&lBattleLock &7- Help");
        MessageUtil.send(sender, "&8&m-----------------------------");
        MessageUtil.send(sender, "&e/battlelock reload &7- Reload configuration");
        MessageUtil.send(sender, "&e/battlelock status [player] &7- Check combat status");
        MessageUtil.send(sender, "&e/battlelock tag <player> &7- Tag player in combat");
        MessageUtil.send(sender, "&e/battlelock untag <player> &7- Remove combat tag");
        MessageUtil.send(sender, "&e/battlelock list &7- List players in combat");
        MessageUtil.send(sender, "&e/combat &7- Check your combat status");
        MessageUtil.send(sender, "&8&m-----------------------------");
    }
    
    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, 
                                                @NotNull Command command, 
                                                @NotNull String alias, 
                                                @NotNull String[] args) {
        
        List<String> completions = new ArrayList<>();
        
        if (args.length == 1) {
            completions.addAll(Arrays.asList("reload", "status", "tag", "untag", "list", "help"));
        } else if (args.length == 2) {
            String subCommand = args[0].toLowerCase();
            if (subCommand.equals("status") || subCommand.equals("tag") || subCommand.equals("untag")) {
                return Bukkit.getOnlinePlayers().stream()
                        .map(Player::getName)
                        .collect(Collectors.toList());
            }
        }
        
        return completions.stream()
                .filter(s -> s.toLowerCase().startsWith(args[args.length - 1].toLowerCase()))
                .collect(Collectors.toList());
    }
}
