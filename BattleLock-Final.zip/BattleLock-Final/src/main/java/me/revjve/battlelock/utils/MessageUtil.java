package me.revjve.battlelock.utils;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/**
 * Utility class for message formatting and sending
 */
public class MessageUtil {
    
    /**
     * Colorize a string with & color codes
     */
    public static String colorize(String message) {
        return ChatColor.translateAlternateColorCodes('&', message);
    }
    
    /**
     * Colorize and convert to Component
     */
    public static Component colorize(Component component) {
        return component;
    }
    
    /**
     * Convert colored string to Component
     */
    public static Component toComponent(String message) {
        return LegacyComponentSerializer.legacyAmpersand().deserialize(message);
    }
    
    /**
     * Send a colored message to a player
     */
    public static void send(Player player, String message) {
        if (message == null || message.isEmpty()) {
            return;
        }
        player.sendMessage(toComponent(message));
    }
    
    /**
     * Send a colored message to a command sender
     */
    public static void send(CommandSender sender, String message) {
        if (message == null || message.isEmpty()) {
            return;
        }
        sender.sendMessage(toComponent(message));
    }
    
    /**
     * Send a message with prefix
     */
    public static void sendWithPrefix(CommandSender sender, String prefix, String message) {
        send(sender, prefix + message);
    }
    
    /**
     * Format time from seconds to readable format
     */
    public static String formatTime(long seconds) {
        if (seconds < 60) {
            return seconds + "s";
        } else if (seconds < 3600) {
            long minutes = seconds / 60;
            long secs = seconds % 60;
            return minutes + "m " + secs + "s";
        } else {
            long hours = seconds / 3600;
            long minutes = (seconds % 3600) / 60;
            return hours + "h " + minutes + "m";
        }
    }
}
