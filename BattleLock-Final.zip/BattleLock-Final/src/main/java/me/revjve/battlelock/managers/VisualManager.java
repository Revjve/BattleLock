package me.revjve.battlelock.managers;

import me.revjve.battlelock.BattleLock;
import me.revjve.battlelock.utils.MessageUtil;
import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Particle;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Manages visual effects for players in combat
 */
public class VisualManager {
    
    private final BattleLock plugin;
    private final Map<UUID, BukkitTask> particleTasks;
    private final Map<UUID, BukkitTask> actionBarTasks;
    private final Map<UUID, BossBar> bossBars;
    
    public VisualManager(BattleLock plugin) {
        this.plugin = plugin;
        this.particleTasks = new HashMap<>();
        this.actionBarTasks = new HashMap<>();
        this.bossBars = new HashMap<>();
    }
    
    /**
     * Start all visual effects for a player
     */
    public void startEffects(Player player) {
        if (plugin.getConfigManager().isGlowingEnabled()) {
            startGlowing(player);
        }
        
        if (plugin.getConfigManager().isParticlesEnabled()) {
            startParticles(player);
        }
        
        if (plugin.getConfigManager().isActionBarEnabled()) {
            startActionBar(player);
        }
        
        if (plugin.getConfigManager().isBossBarEnabled()) {
            startBossBar(player);
        }
    }
    
    /**
     * Stop all visual effects for a player
     */
    public void stopEffects(Player player) {
        stopGlowing(player);
        stopParticles(player);
        stopActionBar(player);
        stopBossBar(player);
    }
    
    /**
     * Start glowing effect
     */
    private void startGlowing(Player player) {
        player.setGlowing(true);
        
        // Note: Glowing color requires teams/scoreboards in Paper
        // This is a basic implementation
        try {
            String colorName = plugin.getConfigManager().getGlowingColor(player.getWorld());
            // Color is managed by scoreboard teams if needed
        } catch (Exception e) {
            plugin.getLogger().warning("Failed to set glowing color: " + e.getMessage());
        }
    }
    
    /**
     * Stop glowing effect
     */
    private void stopGlowing(Player player) {
        player.setGlowing(false);
    }
    
    /**
     * Start particle effects
     */
    private void startParticles(Player player) {
        UUID uuid = player.getUniqueId();
        
        // Cancel existing task if any
        stopParticles(player);
        
        int interval = plugin.getConfigManager().getParticleInterval();
        String particleType = plugin.getConfigManager().getParticleType();
        int amount = plugin.getConfigManager().getParticleAmount();
        
        BukkitTask task = new BukkitRunnable() {
            @Override
            public void run() {
                if (!player.isOnline() || !plugin.getCombatManager().isInCombat(player)) {
                    cancel();
                    return;
                }
                
                try {
                    Particle particle = Particle.valueOf(particleType.toUpperCase());
                    player.getWorld().spawnParticle(
                            particle,
                            player.getLocation().add(0, 1, 0),
                            amount,
                            0.5, 0.5, 0.5,
                            0.01
                    );
                } catch (IllegalArgumentException e) {
                    plugin.getLogger().warning("Invalid particle type: " + particleType);
                    cancel();
                }
            }
        }.runTaskTimer(plugin, 0L, interval);
        
        particleTasks.put(uuid, task);
    }
    
    /**
     * Stop particle effects
     */
    private void stopParticles(Player player) {
        UUID uuid = player.getUniqueId();
        BukkitTask task = particleTasks.remove(uuid);
        if (task != null) {
            task.cancel();
        }
    }
    
    /**
     * Start action bar timer
     */
    private void startActionBar(Player player) {
        UUID uuid = player.getUniqueId();
        
        // Cancel existing task if any
        stopActionBar(player);
        
        int interval = plugin.getConfigManager().getActionBarUpdateInterval();
        String format = plugin.getConfigManager().getActionBarFormat();
        
        BukkitTask task = new BukkitRunnable() {
            @Override
            public void run() {
                if (!player.isOnline() || !plugin.getCombatManager().isInCombat(player)) {
                    cancel();
                    return;
                }
                
                long remainingTime = plugin.getCombatManager().getRemainingTime(player);
                String message = format.replace("{time}", String.valueOf(remainingTime));
                
                player.sendActionBar(MessageUtil.toComponent(message));
            }
        }.runTaskTimer(plugin, 0L, interval);
        
        actionBarTasks.put(uuid, task);
    }
    
    /**
     * Stop action bar timer
     */
    private void stopActionBar(Player player) {
        UUID uuid = player.getUniqueId();
        BukkitTask task = actionBarTasks.remove(uuid);
        if (task != null) {
            task.cancel();
        }
        
        // Clear action bar
        player.sendActionBar(Component.empty());
    }
    
    /**
     * Start boss bar
     */
    private void startBossBar(Player player) {
        UUID uuid = player.getUniqueId();
        
        // Remove existing boss bar if any
        stopBossBar(player);
        
        String title = plugin.getConfigManager().getBossBarTitle();
        String colorName = plugin.getConfigManager().getBossBarColor();
        String styleName = plugin.getConfigManager().getBossBarStyle();
        boolean showTimer = plugin.getConfigManager().showBossBarTimer();
        
        BossBar.Color color = parseBossBarColor(colorName);
        BossBar.Overlay overlay = parseBossBarOverlay(styleName);
        
        BossBar bossBar = BossBar.bossBar(
                MessageUtil.toComponent(title),
                1.0f,
                color,
                overlay
        );
        
        player.showBossBar(bossBar);
        bossBars.put(uuid, bossBar);
        
        // Update boss bar timer
        int duration = plugin.getConfigManager().getCombatDuration(player.getWorld());
        
        new BukkitRunnable() {
            int ticks = 0;
            final int maxTicks = duration * 20;
            
            @Override
            public void run() {
                if (!player.isOnline() || !plugin.getCombatManager().isInCombat(player)) {
                    cancel();
                    stopBossBar(player);
                    return;
                }
                
                float progress = 1.0f - ((float) ticks / maxTicks);
                bossBar.progress(Math.max(0, Math.min(1, progress)));
                
                if (showTimer) {
                    long remaining = plugin.getCombatManager().getRemainingTime(player);
                    String updatedTitle = title.replace("{time}", String.valueOf(remaining));
                    bossBar.name(MessageUtil.toComponent(updatedTitle));
                }
                
                ticks += 2;
            }
        }.runTaskTimer(plugin, 0L, 2L);
    }
    
    /**
     * Stop boss bar
     */
    private void stopBossBar(Player player) {
        UUID uuid = player.getUniqueId();
        BossBar bossBar = bossBars.remove(uuid);
        
        if (bossBar != null) {
            player.hideBossBar(bossBar);
        }
    }
    
    /**
     * Parse boss bar color from string
     */
    private BossBar.Color parseBossBarColor(String colorName) {
        try {
            return BossBar.Color.valueOf(colorName.toUpperCase());
        } catch (IllegalArgumentException e) {
            plugin.getLogger().warning("Invalid boss bar color: " + colorName + ", using RED");
            return BossBar.Color.RED;
        }
    }
    
    /**
     * Parse boss bar overlay from string
     */
    private BossBar.Overlay parseBossBarOverlay(String styleName) {
        try {
            return switch (styleName.toUpperCase()) {
                case "SEGMENTED_6" -> BossBar.Overlay.NOTCHED_6;
                case "SEGMENTED_10" -> BossBar.Overlay.NOTCHED_10;
                case "SEGMENTED_12" -> BossBar.Overlay.NOTCHED_12;
                case "SEGMENTED_20" -> BossBar.Overlay.NOTCHED_20;
                default -> BossBar.Overlay.PROGRESS;
            };
        } catch (IllegalArgumentException e) {
            plugin.getLogger().warning("Invalid boss bar style: " + styleName + ", using PROGRESS");
            return BossBar.Overlay.PROGRESS;
        }
    }
    
    /**
     * Cleanup all effects
     */
    public void cleanup() {
        // Cancel all tasks
        particleTasks.values().forEach(BukkitTask::cancel);
        actionBarTasks.values().forEach(BukkitTask::cancel);
        
        // Remove all boss bars
        for (Player player : Bukkit.getOnlinePlayers()) {
            BossBar bossBar = bossBars.get(player.getUniqueId());
            if (bossBar != null) {
                player.hideBossBar(bossBar);
            }
        }
        
        particleTasks.clear();
        actionBarTasks.clear();
        bossBars.clear();
    }
}
