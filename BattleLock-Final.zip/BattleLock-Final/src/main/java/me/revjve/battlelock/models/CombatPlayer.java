package me.revjve.battlelock.models;

import org.bukkit.entity.Player;
import java.util.UUID;

/**
 * Represents a player in combat with their combat data
 */
public class CombatPlayer {
    
    private final UUID uuid;
    private final String name;
    private long combatEndTime;
    private UUID lastAttacker;
    private boolean inCombat;
    
    public CombatPlayer(Player player) {
        this.uuid = player.getUniqueId();
        this.name = player.getName();
        this.inCombat = false;
    }
    
    public UUID getUuid() {
        return uuid;
    }
    
    public String getName() {
        return name;
    }
    
    public long getCombatEndTime() {
        return combatEndTime;
    }
    
    public void setCombatEndTime(long combatEndTime) {
        this.combatEndTime = combatEndTime;
    }
    
    public UUID getLastAttacker() {
        return lastAttacker;
    }
    
    public void setLastAttacker(UUID lastAttacker) {
        this.lastAttacker = lastAttacker;
    }
    
    public boolean isInCombat() {
        return inCombat && System.currentTimeMillis() < combatEndTime;
    }
    
    public void setInCombat(boolean inCombat) {
        this.inCombat = inCombat;
    }
    
    public long getRemainingTime() {
        if (!isInCombat()) {
            return 0;
        }
        return (combatEndTime - System.currentTimeMillis()) / 1000;
    }
    
    public void tagCombat(int duration, UUID attacker) {
        this.inCombat = true;
        this.combatEndTime = System.currentTimeMillis() + (duration * 1000L);
        this.lastAttacker = attacker;
    }
    
    public void untagCombat() {
        this.inCombat = false;
        this.combatEndTime = 0;
        this.lastAttacker = null;
    }
}
