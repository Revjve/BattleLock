package me.revjve.battlelock.listeners;

import me.revjve.battlelock.BattleLock;
import me.revjve.battlelock.utils.MessageUtil;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.projectiles.ProjectileSource;

/**
 * Handles combat-related events
 */
public class CombatListener implements Listener {
    
    private final BattleLock plugin;
    
    public CombatListener(BattleLock plugin) {
        this.plugin = plugin;
    }
    
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        // Check if damaged entity is a player
        if (!(event.getEntity() instanceof Player victim)) {
            return;
        }
        
        // Check if attacker is a player
        Player attacker = null;
        Entity damager = event.getDamager();
        
        // Direct damage from player
        if (damager instanceof Player) {
            attacker = (Player) damager;
        }
        // Projectile damage from player
        else if (damager instanceof Projectile projectile) {
            ProjectileSource shooter = projectile.getShooter();
            if (shooter instanceof Player) {
                attacker = (Player) shooter;
            }
        }
        
        // Check minimum damage
        if (event.getFinalDamage() < plugin.getConfigManager().getMinimumDamage()) {
            return;
        }
        
        // Tag both players if PvP
        if (attacker != null) {
            // Don't tag if either player has bypass permission
            if (!attacker.hasPermission("battlelock.bypass") && 
                !victim.hasPermission("battlelock.bypass")) {
                
                // Check if world is enabled
                if (plugin.getConfigManager().isEnabledInWorld(victim.getWorld())) {
                    plugin.getCombatManager().tagPlayer(victim, attacker);
                    plugin.getCombatManager().tagPlayer(attacker, victim);
                }
            }
        }
        // Tag on mob damage if enabled
        else if (plugin.getConfigManager().shouldTagOnMobDamage()) {
            if (plugin.getConfigManager().isEnabledInWorld(victim.getWorld())) {
                plugin.getCombatManager().tagPlayer(victim, null);
            }
        }
    }
    
    @EventHandler(priority = EventPriority.MONITOR)
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player player = event.getPlayer();
        
        // Remove combat tag on death if configured
        if (plugin.getConfigManager().shouldRemoveOnDeath()) {
            if (plugin.getCombatManager().isInCombat(player)) {
                plugin.getCombatManager().untagPlayer(player);
            }
        }
    }
}
