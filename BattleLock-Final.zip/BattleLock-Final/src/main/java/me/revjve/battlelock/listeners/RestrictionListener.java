package me.revjve.battlelock.listeners;

import me.revjve.battlelock.BattleLock;
import me.revjve.battlelock.utils.MessageUtil;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityToggleGlideEvent;
import org.bukkit.event.player.*;

import java.util.List;

/**
 * Handles restriction enforcement during combat
 */
public class RestrictionListener implements Listener {
    
    private final BattleLock plugin;
    
    public RestrictionListener(BattleLock plugin) {
        this.plugin = plugin;
    }
    
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPlayerCommandPreprocess(PlayerCommandPreprocessEvent event) {
        Player player = event.getPlayer();
        
        if (!plugin.getCombatManager().isInCombat(player)) {
            return;
        }
        
        String command = event.getMessage().toLowerCase();
        String baseCommand = command.split(" ")[0];
        
        // Check allowed commands first
        List<String> allowedCommands = plugin.getConfigManager().getAllowedCommands();
        for (String allowed : allowedCommands) {
            if (baseCommand.startsWith(allowed.toLowerCase())) {
                return;
            }
        }
        
        // Check blocked commands
        List<String> blockedCommands = plugin.getConfigManager().getBlockedCommands();
        for (String blocked : blockedCommands) {
            String blockedLower = blocked.toLowerCase();
            
            // Support wildcards
            if (blockedLower.endsWith("*")) {
                String prefix = blockedLower.substring(0, blockedLower.length() - 1);
                if (baseCommand.startsWith(prefix)) {
                    event.setCancelled(true);
                    MessageUtil.sendWithPrefix(player, 
                            plugin.getConfigManager().getPrefix(),
                            plugin.getConfigManager().getCommandBlockedMessage());
                    return;
                }
            } else if (baseCommand.equals(blockedLower)) {
                event.setCancelled(true);
                MessageUtil.sendWithPrefix(player, 
                        plugin.getConfigManager().getPrefix(),
                        plugin.getConfigManager().getCommandBlockedMessage());
                return;
            }
        }
    }
    
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPlayerInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        
        if (!plugin.getCombatManager().isInCombat(player)) {
            return;
        }
        
        if (event.getAction() != Action.RIGHT_CLICK_AIR && 
            event.getAction() != Action.RIGHT_CLICK_BLOCK) {
            return;
        }
        
        if (event.getItem() == null) {
            return;
        }
        
        Material item = event.getItem().getType();
        
        // Check ender pearls
        if (item == Material.ENDER_PEARL && 
            plugin.getConfigManager().isEnderpearLsBlocked(player.getWorld())) {
            event.setCancelled(true);
            MessageUtil.sendWithPrefix(player,
                    plugin.getConfigManager().getPrefix(),
                    plugin.getConfigManager().getItemBlockedMessage());
            return;
        }
        
        // Check chorus fruit
        if (item == Material.CHORUS_FRUIT && 
            plugin.getConfigManager().isChorusFruitBlocked()) {
            event.setCancelled(true);
            MessageUtil.sendWithPrefix(player,
                    plugin.getConfigManager().getPrefix(),
                    plugin.getConfigManager().getItemBlockedMessage());
            return;
        }
        
        // Check buckets
        if (plugin.getConfigManager().shouldBlockBuckets() &&
            (item == Material.WATER_BUCKET || item == Material.LAVA_BUCKET)) {
            event.setCancelled(true);
            MessageUtil.sendWithPrefix(player,
                    plugin.getConfigManager().getPrefix(),
                    plugin.getConfigManager().getActionDeniedMessage());
            return;
        }
        
        // Check blocked items list
        List<String> blockedItems = plugin.getConfigManager().getBlockedItems();
        if (blockedItems.contains(item.name())) {
            event.setCancelled(true);
            MessageUtil.sendWithPrefix(player,
                    plugin.getConfigManager().getPrefix(),
                    plugin.getConfigManager().getItemBlockedMessage());
        }
    }
    
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onEntityToggleGlide(EntityToggleGlideEvent event) {
        if (!(event.getEntity() instanceof Player player)) {
            return;
        }
        
        if (!plugin.getCombatManager().isInCombat(player)) {
            return;
        }
        
        if (event.isGliding() && 
            plugin.getConfigManager().isElytraBlocked(player.getWorld())) {
            event.setCancelled(true);
            MessageUtil.sendWithPrefix(player,
                    plugin.getConfigManager().getPrefix(),
                    plugin.getConfigManager().getActionDeniedMessage());
        }
    }
    
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPlayerToggleFlight(PlayerToggleFlightEvent event) {
        Player player = event.getPlayer();
        
        if (!plugin.getCombatManager().isInCombat(player)) {
            return;
        }
        
        if (event.isFlying() && plugin.getConfigManager().isFlightDisabled()) {
            event.setCancelled(true);
            player.setAllowFlight(false);
            player.setFlying(false);
            MessageUtil.sendWithPrefix(player,
                    plugin.getConfigManager().getPrefix(),
                    plugin.getConfigManager().getActionDeniedMessage());
        }
    }
    
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPlayerTeleport(PlayerTeleportEvent event) {
        Player player = event.getPlayer();
        
        if (!plugin.getCombatManager().isInCombat(player)) {
            return;
        }
        
        // Allow teleports caused by damage (like enderpearls that were allowed)
        if (event.getCause() == PlayerTeleportEvent.TeleportCause.ENDER_PEARL) {
            if (!plugin.getConfigManager().isEnderpearLsBlocked(player.getWorld())) {
                return;
            }
        }
        
        // Block teleports if configured
        if (plugin.getConfigManager().isTeleportBlocked()) {
            // Allow teleports within same world (like /back or respawn)
            if (event.getFrom().getWorld().equals(event.getTo().getWorld())) {
                double distance = event.getFrom().distance(event.getTo());
                if (distance < 5) { // Allow small teleports
                    return;
                }
            }
            
            // Block command teleports
            if (event.getCause() == PlayerTeleportEvent.TeleportCause.COMMAND ||
                event.getCause() == PlayerTeleportEvent.TeleportCause.PLUGIN) {
                event.setCancelled(true);
                MessageUtil.sendWithPrefix(player,
                        plugin.getConfigManager().getPrefix(),
                        plugin.getConfigManager().getActionDeniedMessage());
            }
        }
    }
    
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPlayerBedEnter(PlayerBedEnterEvent event) {
        Player player = event.getPlayer();
        
        if (!plugin.getCombatManager().isInCombat(player)) {
            return;
        }
        
        if (plugin.getConfigManager().shouldBlockBedSet()) {
            event.setCancelled(true);
            MessageUtil.sendWithPrefix(player,
                    plugin.getConfigManager().getPrefix(),
                    plugin.getConfigManager().getActionDeniedMessage());
        }
    }
    
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPlayerDropItem(PlayerDropItemEvent event) {
        Player player = event.getPlayer();
        
        if (!plugin.getCombatManager().isInCombat(player)) {
            return;
        }
        
        if (plugin.getConfigManager().shouldBlockItemDrop()) {
            event.setCancelled(true);
            MessageUtil.sendWithPrefix(player,
                    plugin.getConfigManager().getPrefix(),
                    plugin.getConfigManager().getActionDeniedMessage());
        }
    }
    
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPlayerPickupItem(PlayerAttemptPickupItemEvent event) {
        Player player = event.getPlayer();
        
        if (!plugin.getCombatManager().isInCombat(player)) {
            return;
        }
        
        if (plugin.getConfigManager().shouldBlockItemPickup()) {
            event.setCancelled(true);
        }
    }
}
